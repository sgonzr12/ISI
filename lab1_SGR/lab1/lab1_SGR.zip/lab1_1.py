#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Feb 22 11:19:46 2023

@author: mines46
"""
print("introduce grados celsius:")
tempetureC = int(input())
tempetureF = ((9/5)*tempetureC)+32
print(f"the tempeture of {tempetureC} degrees celsius corresponds to {tempetureF} degrees farenheit")